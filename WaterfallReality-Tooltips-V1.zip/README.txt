WaterfallReality - tooltip backgrounds
======================================

Der's Chromatic Frames ships the animated tooltip BORDERS in the minecraft
namespace (mythic_frame.png, legendary_frame.png, ...), but a vanilla
tooltip_style needs two sprites:

    tooltip/<style>_background      and     tooltip/<style>_frame

Vanilla only ships tooltip/background and tooltip/frame, so without the
matching *_background sprite the body of the tooltip renders as the pink and
black missing texture.

This pack fills that gap. It is the vanilla tooltip background copied under
every style name Der's pack provides a frame for, nothing more.

Load order (top of the list wins in Minecraft's resource pack screen):

    WaterfallReality-Tooltips       <- this pack, on top
    Der's Chromatic Frames
    Flaming Swords
    Mace to Steampunk Hammer

Order between these four does not actually matter, since none of them touch
the same files - but keeping this one on top makes it obvious what it is for.
